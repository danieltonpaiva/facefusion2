#!/usr/bin/env python3

from facefusion import core
if __name__ == '__main__':
    core.cli()
